<?php

namespace MantraLibrary\Model;

/**
 * Class ProjectId.
 *
 * @category class
 * @package MantraLibrary\Model
 */
class ProjectId {
  public $projectId;
  public $nodeId;
  public $status;

}
